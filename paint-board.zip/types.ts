export interface Point {
  x: number;
  y: number;
}

export interface Layer {
  id: string;
  name: string;
  visible: boolean;
}

export interface CanvasActions {
  clear: () => void;
  undo: () => void;
  redo: () => void;
  getImageData: () => string;
}

export type Tool = 'pen' | 'eraser' | 'pan';

// Types for New Canvas Feature
export type Unit = 'px' | 'mm' | 'in';
export type ColorSpace = 'sRGB' | 'P3' | 'CMYK';

export interface CanvasOptions {
  width: number; // in pixels
  height: number; // in pixels
}

export interface CanvasPreset extends CanvasOptions {
  name: string;
  unit: Unit;
  physicalWidth: number;
  physicalHeight: number;
  colorSpace: ColorSpace;
}

// Types for Brush Dynamics
export interface BrushDynamics {
    opacity: number;
    flow: number;
    jitter: number;
}

// Types for View Transform
export interface PanOffset {
    x: number;
    y: number;
}

export interface ViewTransform {
    zoom: number;
    pan: PanOffset;
}

// Types for Save/Load Project
export interface ProjectFile {
    canvasOptions: CanvasOptions;
    layers: Layer[];
    layerData: Record<string, string>; // layerId -> imageData URL
    toolSettings: {
        tool: Tool;
        color: string;
        brushSize: number;
        opacity: number;
        flow: number;
        jitter: number;
    };
    viewTransform: ViewTransform;
    activeLayerId: string;
    initialLayerId: string;
}
