import React from 'react';

interface ColorPanelProps {
  color: string;
  onColorSwatchClick: () => void;
}

const ColorPanel: React.FC<ColorPanelProps> = ({ color, onColorSwatchClick }) => {
  return (
    <div className="p-4 space-y-2">
      <h3 className="text-lg font-semibold mb-2 text-gray-700 dark:text-gray-300">Color</h3>
      <div className="flex items-center space-x-3">
        <button
          onClick={onColorSwatchClick}
          className="w-10 h-10 rounded-full border-2 border-gray-300 dark:border-gray-600 ring-2 ring-offset-2 ring-transparent dark:ring-offset-gray-800 focus:ring-blue-500 focus:outline-none transition-transform transform hover:scale-110"
          style={{ backgroundColor: color }}
          aria-label="Open color picker"
        />
        <span className="font-mono text-sm bg-gray-100 dark:bg-gray-700 rounded-md px-2 py-1">{color}</span>
      </div>
    </div>
  );
};

export default ColorPanel;
