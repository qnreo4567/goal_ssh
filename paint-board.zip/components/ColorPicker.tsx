
import React from 'react';

interface ColorPickerProps {
  selectedColor: string;
  onColorChange: (color: string) => void;
}

const colors = [
  '#000000', '#4B5563', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6', '#FFFFFF',
  '#EF4444', '#F97316', '#F59E0B', '#EAB308', '#84CC16', '#22C55E', '#10B981', '#14B8A6',
  '#06B6D4', '#0EA5E9', '#3B82F6', '#6366F1', '#8B5CF6', '#A855F7', '#D946EF', '#EC4899',
  '#F43F5E', '#FCA5A5', '#FDBA74', '#FCD34D', '#FDE047', '#A3E635', '#86EFAC', '#6EE7B7',
  '#67E8F9', '#7DD3FC', '#93C5FD', '#A5B4FC', '#C4B5FD', '#D8B4FE', '#F0ABFC', '#FBCFE8',
];

const ColorPicker: React.FC<ColorPickerProps> = ({ selectedColor, onColorChange }) => {
  return (
    <div className="grid grid-cols-8 gap-2">
      {colors.map((color) => (
        <button
          key={color}
          onClick={() => onColorChange(color)}
          className={`w-10 h-10 rounded-full border-2 transition-transform transform hover:scale-110 ${
            selectedColor.toUpperCase() === color.toUpperCase()
              ? 'ring-2 ring-offset-2 ring-blue-500 dark:ring-offset-gray-800'
              : 'border-gray-300 dark:border-gray-600'
          }`}
          style={{ backgroundColor: color }}
          aria-label={`Select color ${color}`}
        />
      ))}
    </div>
  );
};

export default ColorPicker;