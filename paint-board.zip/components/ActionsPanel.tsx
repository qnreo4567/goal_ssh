import React from 'react';
import IconButton from './IconButton';
import { UndoIcon, RedoIcon, ClearIcon } from './Icons';

interface ActionsPanelProps {
  onUndo: () => void;
  onRedo: () => void;
  onClear: () => void;
}

const ActionsPanel: React.FC<ActionsPanelProps> = ({ onUndo, onRedo, onClear }) => {
  return (
    <div className="p-4 space-y-2">
      <h3 className="text-lg font-semibold mb-2 text-gray-700 dark:text-gray-300">Actions</h3>
      <div className="flex items-center space-x-2">
        <IconButton label="Undo" onClick={onUndo}><UndoIcon /></IconButton>
        <IconButton label="Redo" onClick={onRedo}><RedoIcon /></IconButton>
        <IconButton label="Clear" onClick={onClear}><ClearIcon /></IconButton>
      </div>
    </div>
  );
};

export default ActionsPanel;
