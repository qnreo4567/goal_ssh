import React, { useImperativeHandle, forwardRef } from 'react';
import useDrawing from '../hooks/useDrawing';
import type { CanvasActions, Tool, PanOffset } from '../types';

// A canvas component for a single layer
interface LayerCanvasProps {
  width: number;
  height: number;
  color: string;
  brushSize: number;
  opacity: number;
  flow: number;
  jitter: number;
  tool: Tool;
  isActive: boolean;
  isVisible: boolean;
  isBaseLayer: boolean;
  isPanActive: boolean;
  initialImageData?: string;
  zoom: number;
  pan: PanOffset;
}

const LayerCanvas = forwardRef<CanvasActions, LayerCanvasProps>((props, ref) => {
  const { canvasRef, ...actions } = useDrawing(props);

  useImperativeHandle(ref, () => ({
    clear: actions.clearCanvas,
    undo: actions.undo,
    redo: actions.redo,
    getImageData: actions.getImageData,
  }));

  return (
    <canvas
      ref={canvasRef}
      width={props.width}
      height={props.height}
      className={`absolute top-0 left-0 rounded-lg touch-none ${props.isActive && !props.isPanActive ? 'cursor-crosshair z-10' : 'pointer-events-none'}`}
      style={{ display: props.isVisible ? 'block' : 'none' }}
    />
  );
});

LayerCanvas.displayName = 'LayerCanvas';

export default LayerCanvas;
