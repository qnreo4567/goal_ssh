
import React from 'react';

interface BrushSliderProps {
  brushSize: number;
  onSizeChange: (size: number) => void;
}

const BrushSlider: React.FC<BrushSliderProps> = ({ brushSize, onSizeChange }) => {
  return (
    <div className="flex items-center space-x-4">
      <input
        type="range"
        min="1"
        max="50"
        value={brushSize}
        onChange={(e) => onSizeChange(Number(e.target.value))}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
      />
      <span className="font-mono text-sm w-8 text-center bg-gray-200 dark:bg-gray-700 rounded-md py-1">
        {brushSize}
      </span>
    </div>
  );
};

export default BrushSlider;
