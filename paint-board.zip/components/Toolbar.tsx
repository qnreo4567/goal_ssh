import React, { useRef, useState, useEffect } from 'react';
import type { Layer, Tool } from '../types';
import { useDraggable } from '../hooks/useDraggable';

// Import Panels
import LayersPanel from './LayersPanel';
import FilePanel from './FilePanel';
import ToolsPanel from './ToolsPanel';
import ActionsPanel from './ActionsPanel';
import ColorPanel from './ColorPanel';
import BrushPanel from './BrushPanel';
import ColorPickerModal from './ColorPickerModal';
import IconButton from './IconButton';

// Import Icons
import {
    DragHandleIcon, RowLayoutIcon, ColumnLayoutIcon,
    LayersIcon, FilePlus2Icon, PenIcon, UndoIcon, PaletteIcon, BrushIcon
} from './Icons';

interface ToolbarProps {
  color: string;
  setColor: (color: string) => void;
  brushSize: number;
  setBrushSize: (size: number) => void;
  opacity: number;
  setOpacity: (opacity: number) => void;
  flow: number;
  setFlow: (flow: number) => void;
  jitter: number;
  setJitter: (jitter: number) => void;
  tool: Tool;
  setTool: (tool: Tool) => void;
  onClear: () => void;
  onUndo: () => void;
  onRedo: () => void;
  layers: Layer[];
  activeLayerId: string;
  onAddLayer: () => void;
  onDeleteLayer: (id: string) => void;
  onSelectLayer: (id: string) => void;
  onToggleVisibility: (id: string) => void;
  containerRef: React.RefObject<HTMLDivElement>;
  onNewCanvasClick: () => void;
  onSaveProject: () => void;
  onLoadProject: (file: File) => void;
}

const Toolbar: React.FC<ToolbarProps> = ({
  color, setColor, brushSize, setBrushSize, tool, setTool,
  onClear, onUndo, onRedo, layers, activeLayerId,
  onAddLayer, onDeleteLayer, onSelectLayer, onToggleVisibility,
  containerRef, onNewCanvasClick, onSaveProject, onLoadProject,
  opacity, setOpacity, flow, setFlow, jitter, setJitter
}) => {
  const dragRef = useRef<HTMLDivElement>(null);
  const { position, onPointerDown, reposition } = useDraggable(dragRef, containerRef);
  const [layoutMode, setLayoutMode] = useState<'column' | 'row'>('column');
  const [isColorModalOpen, setIsColorModalOpen] = useState(false);
  const [activePanel, setActivePanel] = useState<string | null>(null);

  const handlePanelToggle = (panel: string) => {
    setActivePanel(current => (current === panel ? null : panel));
  };

  useEffect(() => {
    const timer = setTimeout(() => {
        reposition();
    }, 50);
    return () => clearTimeout(timer);
  }, [layoutMode, activePanel, reposition]);

  return (
    <>
      <div
        ref={dragRef}
        className="absolute bg-transparent z-20 touch-none flex"
        style={{
          top: `${position.y}px`,
          left: `${position.x}px`,
          flexDirection: layoutMode === 'column' ? 'row' : 'column'
        }}
      >
        {/* Icon Bar */}
        <div className="bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur-sm border border-gray-200 dark:border-gray-700 rounded-lg shadow-xl p-2 flex flex-col items-center">
          <div
            className="cursor-grab active:cursor-grabbing pb-2 mb-2 w-full flex justify-center border-b border-gray-200 dark:border-gray-700"
            onPointerDown={onPointerDown}
          >
            <DragHandleIcon />
          </div>
          <div className={`flex gap-2 ${layoutMode === 'column' ? 'flex-col' : 'flex-row'}`}>
            <IconButton label="Layers" onClick={() => handlePanelToggle('layers')} isActive={activePanel === 'layers'}><LayersIcon /></IconButton>
            <IconButton label="File" onClick={() => handlePanelToggle('file')} isActive={activePanel === 'file'}><FilePlus2Icon /></IconButton>
            <IconButton label="Tools" onClick={() => handlePanelToggle('tools')} isActive={activePanel === 'tools'}><PenIcon /></IconButton>
            <IconButton label="Actions" onClick={() => handlePanelToggle('actions')} isActive={activePanel === 'actions'}><UndoIcon /></IconButton>
            <IconButton label="Color" onClick={() => handlePanelToggle('color')} isActive={activePanel === 'color'}><PaletteIcon /></IconButton>
            <IconButton label="Brush" onClick={() => handlePanelToggle('brush')} isActive={activePanel === 'brush'}><BrushIcon /></IconButton>
            
            <div className={`${layoutMode === 'column' ? 'border-t my-1' : 'border-l mx-1'} border-gray-200 dark:border-gray-700`}></div>
            
            <IconButton
              label={layoutMode === 'column' ? "Row layout" : "Column layout"}
              onClick={() => setLayoutMode(prev => prev === 'column' ? 'row' : 'column')}
            >
              {layoutMode === 'column' ? <RowLayoutIcon /> : <ColumnLayoutIcon />}
            </IconButton>
          </div>
        </div>

        {/* Fly-out Panel */}
        {activePanel && (
          <div className={`bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur-sm border border-gray-200 dark:border-gray-700 rounded-lg shadow-xl ${layoutMode === 'column' ? 'ml-2 w-72' : 'mt-2'}`}>
            {activePanel === 'layers' && <LayersPanel layers={layers} activeLayerId={activeLayerId} onAddLayer={onAddLayer} onDeleteLayer={onDeleteLayer} onSelectLayer={onSelectLayer} onToggleVisibility={onToggleVisibility} />}
            {activePanel === 'file' && <FilePanel onNewCanvasClick={onNewCanvasClick} onSaveProject={onSaveProject} onLoadProject={onLoadProject} />}
            {activePanel === 'tools' && <ToolsPanel tool={tool} setTool={setTool} />}
            {activePanel === 'actions' && <ActionsPanel onUndo={onUndo} onRedo={onRedo} onClear={onClear} />}
            {activePanel === 'color' && <ColorPanel color={color} onColorSwatchClick={() => setIsColorModalOpen(true)} />}
            {activePanel === 'brush' && <BrushPanel brushSize={brushSize} setBrushSize={setBrushSize} opacity={opacity} setOpacity={setOpacity} flow={flow} setFlow={setFlow} jitter={jitter} setJitter={setJitter} />}
          </div>
        )}
      </div>

      <ColorPickerModal
        isOpen={isColorModalOpen}
        onClose={() => setIsColorModalOpen(false)}
        selectedColor={color}
        onColorChange={setColor}
      />
    </>
  );
};

export default Toolbar;
