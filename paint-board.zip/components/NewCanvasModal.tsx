import React, { useState, useEffect, useCallback } from 'react';
import { useCanvasPresets } from '../hooks/useCanvasPresets';
import CanvasPresetCard from './CanvasPresetCard';
import { CloseIcon, LockIcon, UnlockIcon } from './Icons';
import type { CanvasOptions, CanvasPreset, Unit, ColorSpace } from '../types';

interface NewCanvasModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateCanvas: (options: CanvasOptions) => void;
}

const DPI = 96;
const mmToIn = 0.0393701;

const NewCanvasModal: React.FC<NewCanvasModalProps> = ({ isOpen, onClose, onCreateCanvas }) => {
  const { defaultPresets, recentPresets, addRecentPreset } = useCanvasPresets();

  const [selectedPreset, setSelectedPreset] = useState<CanvasPreset | null>(defaultPresets[0]);
  const [width, setWidth] = useState<number>(defaultPresets[0].physicalWidth);
  const [height, setHeight] = useState<number>(defaultPresets[0].physicalHeight);
  const [unit, setUnit] = useState<Unit>(defaultPresets[0].unit);
  const [colorSpace, setColorSpace] = useState<ColorSpace>(defaultPresets[0].colorSpace);
  const [isRatioLocked, setIsRatioLocked] = useState<boolean>(false);
  const [aspectRatio, setAspectRatio] = useState<number>(defaultPresets[0].physicalWidth / defaultPresets[0].physicalHeight);

  useEffect(() => {
    if (selectedPreset) {
      setWidth(selectedPreset.physicalWidth);
      setHeight(selectedPreset.physicalHeight);
      setUnit(selectedPreset.unit);
      setColorSpace(selectedPreset.colorSpace);
      setAspectRatio(selectedPreset.physicalWidth / selectedPreset.physicalHeight);
    }
  }, [selectedPreset]);

  const handlePresetSelect = (preset: CanvasPreset) => {
    setSelectedPreset(preset);
  };

  const convertToPx = (value: number, fromUnit: Unit): number => {
    if (fromUnit === 'mm') return Math.round(value * mmToIn * DPI);
    if (fromUnit === 'in') return Math.round(value * DPI);
    return value; // px
  };

  const handleCreate = () => {
    const options: CanvasOptions = {
      width: convertToPx(width, unit),
      height: convertToPx(height, unit),
    };
    addRecentPreset({
        physicalWidth: width,
        physicalHeight: height,
        unit,
        colorSpace,
        ...options
    });
    onCreateCanvas(options);
  };
  
  const handleWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newWidth = parseFloat(e.target.value) || 0;
    setWidth(newWidth);
    if(isRatioLocked && newWidth > 0) {
        const newHeight = parseFloat((newWidth / aspectRatio).toFixed(2));
        setHeight(newHeight);
    }
    setSelectedPreset(null);
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newHeight = parseFloat(e.target.value) || 0;
    setHeight(newHeight);
    if(isRatioLocked && newHeight > 0) {
        const newWidth = parseFloat((newHeight * aspectRatio).toFixed(2));
        setWidth(newWidth);
    }
    setSelectedPreset(null);
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl h-full max-h-[90vh] flex"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Left Panel: Presets */}
        <div className="w-1/2 p-6 overflow-y-auto border-r border-gray-200 dark:border-gray-700">
           <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-200">New Canvas</h2>
           {recentPresets.length > 0 && (
            <>
              <h3 className="text-lg font-semibold mt-4 mb-2 text-gray-600 dark:text-gray-400">Recent</h3>
              <div className="grid grid-cols-2 gap-4">
                {recentPresets.map((preset, index) => (
                    <CanvasPresetCard key={`recent-${index}`} preset={preset} onSelect={handlePresetSelect} isSelected={selectedPreset === preset} />
                ))}
              </div>
            </>
           )}
           <h3 className="text-lg font-semibold mt-6 mb-2 text-gray-600 dark:text-gray-400">Templates</h3>
           <div className="grid grid-cols-2 gap-4">
            {defaultPresets.map(preset => (
              <CanvasPresetCard key={preset.name} preset={preset} onSelect={handlePresetSelect} isSelected={selectedPreset === preset} />
            ))}
           </div>
        </div>

        {/* Right Panel: Custom Settings */}
        <div className="w-1/2 p-8 flex flex-col">
          <div className="flex justify-between items-start mb-6">
            <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">{selectedPreset?.name || 'Custom Canvas'}</h3>
            <button onClick={onClose} className="p-2 -mt-2 -mr-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close">
              <CloseIcon />
            </button>
          </div>
          
          <div className="space-y-6 flex-grow">
              <div className="flex items-center space-x-4">
                <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Width</label>
                    <input type="number" value={width} onChange={handleWidthChange} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <button onClick={() => setIsRatioLocked(!isRatioLocked)} className="mt-6 p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
                  {isRatioLocked ? <LockIcon /> : <UnlockIcon />}
                </button>
                <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Height</label>
                    <input type="number" value={height} onChange={handleHeightChange} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Unit</label>
                    <select value={unit} onChange={(e) => setUnit(e.target.value as Unit)} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="px">px</option>
                        <option value="mm">mm</option>
                        <option value="in">in</option>
                    </select>
                </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Color Space</label>
                  <select value={colorSpace} onChange={(e) => setColorSpace(e.target.value as ColorSpace)} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                      <option value="sRGB">sRGB</option>
                      <option value="P3">P3</option>
                      <option value="CMYK">CMYK</option>
                  </select>
              </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-gray-200 dark:border-gray-700">
             <button
                onClick={handleCreate}
                className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-800 transition-colors"
             >
                Create Canvas
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewCanvasModal;
