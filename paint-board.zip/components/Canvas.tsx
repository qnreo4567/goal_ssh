import React, { useRef, useCallback } from 'react';
import LayerCanvas from './LayerCanvas';
import type { CanvasActions, CanvasOptions, Layer, Tool, PanOffset } from '../types';

interface CanvasProps {
  options: CanvasOptions;
  color: string;
  brushSize: number;
  opacity: number;
  flow: number;
  jitter: number;
  tool: Tool;
  layers: Layer[];
  activeLayerId: string;
  initialLayerId: string;
  registerActions: (layerId: string, actions: CanvasActions) => void;
  initialLayerData: Record<string, string> | null;
  zoom: number;
  setZoom: (zoom: number) => void;
  pan: PanOffset;
  setPan: (pan: PanOffset) => void;
  isPanActive: boolean;
}

const Canvas: React.FC<CanvasProps> = ({ 
  options, color, brushSize, opacity, flow, jitter, tool, layers, 
  activeLayerId, initialLayerId, registerActions, initialLayerData,
  zoom, setZoom, pan, setPan, isPanActive,
}) => {
  const viewportRef = useRef<HTMLDivElement>(null);
  const panStart = useRef<PanOffset | null>(null);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const { deltaY } = e;
    const zoomFactor = 0.95;
    const newZoom = deltaY < 0 ? zoom / zoomFactor : zoom * zoomFactor;
    setZoom(Math.max(0.1, Math.min(newZoom, 10)));
  }, [zoom, setZoom]);

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    if (isPanActive) {
      panStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    }
  }, [isPanActive, pan]);
  
  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (panStart.current) {
      e.preventDefault();
      const newPan = {
        x: e.clientX - panStart.current.x,
        y: e.clientY - panStart.current.y
      };
      setPan(newPan);
    }
  }, [setPan]);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    panStart.current = null;
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
  }, []);

  return (
    <div 
      ref={viewportRef}
      className="relative rounded-lg shadow-lg overflow-hidden touch-none"
      style={{ 
        width: '100%',
        height: '100%',
        cursor: isPanActive ? 'grab' : 'default',
      }}
      onWheel={handleWheel}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
    >
      <div
        className="relative bg-white dark:bg-gray-900"
        style={{
          width: `${options.width}px`,
          height: `${options.height}px`,
          transform: `scale(${zoom}) translate(${pan.x / zoom}px, ${pan.y / zoom}px)`,
          transformOrigin: 'top left',
        }}
      >
        <div 
          className="absolute top-0 left-0 w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(45deg, #ccc 25%, transparent 25%), 
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%)`,
            backgroundSize: '20px 20px',
            backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
          }}
        ></div>
        {layers.map((layer) => (
          <LayerCanvas
            key={layer.id}
            ref={(el) => { if (el) { registerActions(layer.id, el); } }}
            width={options.width}
            height={options.height}
            color={color}
            brushSize={brushSize}
            opacity={opacity}
            flow={flow}
            jitter={jitter}
            tool={tool}
            isActive={layer.id === activeLayerId}
            isVisible={layer.visible}
            isBaseLayer={layer.id === initialLayerId}
            isPanActive={isPanActive}
            initialImageData={initialLayerData?.[layer.id]}
            zoom={zoom}
            pan={pan}
          />
        ))}
      </div>
    </div>
  );
};

export default Canvas;
