import React, { useState, useEffect } from 'react';
import ColorPicker from './ColorPicker';
import { CloseIcon } from './Icons';

interface ColorPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedColor: string;
  onColorChange: (color: string) => void;
}

const ColorPickerModal: React.FC<ColorPickerModalProps> = ({ isOpen, onClose, selectedColor, onColorChange }) => {
  const [customColor, setCustomColor] = useState(selectedColor);

  useEffect(() => {
    setCustomColor(selectedColor);
  }, [selectedColor]);
  
  const handleCustomColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setCustomColor(value);
    // Basic hex color validation
    if (/^#[0-9A-F]{6}$/i.test(value)) {
      onColorChange(value);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="color-picker-title"
    >
      <div 
        className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl p-6 w-full max-w-md relative"
        onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside the modal
      >
        <div className="flex justify-between items-center mb-4">
          <h2 id="color-picker-title" className="text-2xl font-bold text-gray-800 dark:text-gray-200">Select Color</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close color picker">
            <CloseIcon />
          </button>
        </div>
        
        <ColorPicker selectedColor={selectedColor} onColorChange={onColorChange} />
        
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-2 text-gray-700 dark:text-gray-300">Custom Color</h3>
          <div className="flex items-center space-x-3">
            <div 
              className="w-10 h-10 rounded-md border-2 border-gray-300 dark:border-gray-600"
              style={{ backgroundColor: selectedColor }}
              aria-label={`Current color preview: ${selectedColor}`}
            />
            <input 
              type="text"
              value={customColor}
              onChange={handleCustomColorChange}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              placeholder="#RRGGBB"
              aria-label="Custom color hex input"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ColorPickerModal;