import React from 'react';

interface SliderProps {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
}

const Slider: React.FC<SliderProps> = ({ label, value, min = 0, max = 1, step = 0.01, onChange }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
    <div className="flex items-center space-x-3">
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
      />
      <span className="font-mono text-sm w-12 text-center bg-gray-100 dark:bg-gray-700 rounded-md py-1">
        {Math.round(value * (max > 1 ? 1 : 100))}
        {max === 1 && '%'}
      </span>
    </div>
  </div>
);

interface BrushPanelProps {
  brushSize: number;
  setBrushSize: (size: number) => void;
  opacity: number;
  setOpacity: (opacity: number) => void;
  flow: number;
  setFlow: (flow: number) => void;
  jitter: number;
  setJitter: (jitter: number) => void;
}

const BrushPanel: React.FC<BrushPanelProps> = ({ 
  brushSize, setBrushSize, opacity, setOpacity, flow, setFlow, jitter, setJitter 
}) => {
  return (
    <div className="p-4 space-y-4">
      <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300">Brush Settings</h3>
      <Slider label="Size" value={brushSize} onChange={setBrushSize} min={1} max={100} step={1} />
      <Slider label="Opacity" value={opacity} onChange={setOpacity} />
      <Slider label="Flow" value={flow} onChange={setFlow} />
      <Slider label="Jitter" value={jitter} onChange={setJitter} max={50} step={1} />
    </div>
  );
};

export default BrushPanel;
