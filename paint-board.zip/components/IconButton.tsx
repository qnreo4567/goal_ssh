
import React from 'react';

interface IconButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  isActive?: boolean;
}

const IconButton: React.FC<IconButtonProps> = ({ children, onClick, label, isActive = false }) => {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={`p-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50
      ${
        isActive 
        ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300' 
        : 'bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600'
      }`}
    >
      {children}
    </button>
  );
};

export default IconButton;
