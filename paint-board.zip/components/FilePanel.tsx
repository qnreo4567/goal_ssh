import React, { useRef } from 'react';
import IconButton from './IconButton';
import { SaveIcon, FolderOpenIcon, FilePlus2Icon } from './Icons';

interface FilePanelProps {
  onNewCanvasClick: () => void;
  onSaveProject: () => void;
  onLoadProject: (file: File) => void;
}

const FilePanel: React.FC<FilePanelProps> = ({ onNewCanvasClick, onSaveProject, onLoadProject }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleOpenClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onLoadProject(file);
    }
  };

  return (
    <div className="p-4 space-y-2">
      <h3 className="text-lg font-semibold mb-2 text-gray-700 dark:text-gray-300">File</h3>
      <div className="flex items-center space-x-2">
        <IconButton label="New Canvas" onClick={onNewCanvasClick}>
          <FilePlus2Icon />
        </IconButton>
        <IconButton label="Open Project" onClick={handleOpenClick}>
          <FolderOpenIcon />
        </IconButton>
        <IconButton label="Save Project" onClick={onSaveProject}>
          <SaveIcon />
        </IconButton>
      </div>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".gemini-paint,application/json"
      />
    </div>
  );
};

export default FilePanel;
