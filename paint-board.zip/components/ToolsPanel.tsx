import React from 'react';
import IconButton from './IconButton';
import { PenIcon, EraserIcon, HandIcon } from './Icons';
import type { Tool } from '../types';

interface ToolsPanelProps {
  tool: Tool;
  setTool: (tool: Tool) => void;
}

const ToolsPanel: React.FC<ToolsPanelProps> = ({ tool, setTool }) => {
  return (
    <div className="p-4 space-y-2">
      <h3 className="text-lg font-semibold mb-2 text-gray-700 dark:text-gray-300">Tools</h3>
      <div className="flex items-center space-x-2">
        <IconButton label="Pen" onClick={() => setTool('pen')} isActive={tool === 'pen'}>
          <PenIcon />
        </IconButton>
        <IconButton label="Eraser" onClick={() => setTool('eraser')} isActive={tool === 'eraser'}>
          <EraserIcon />
        </IconButton>
        <IconButton label="Pan" onClick={() => setTool('pan')} isActive={tool === 'pan'}>
          <HandIcon />
        </IconButton>
      </div>
    </div>
  );
};

export default ToolsPanel;
