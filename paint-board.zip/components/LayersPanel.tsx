import React from 'react';
import type { Layer } from '../types';
import IconButton from './IconButton';
import { AddIcon, TrashIcon, EyeOpenIcon, EyeClosedIcon } from './Icons';

interface LayersPanelProps {
  layers: Layer[];
  activeLayerId: string;
  onSelectLayer: (id: string) => void;
  onAddLayer: () => void;
  onDeleteLayer: (id: string) => void;
  onToggleVisibility: (id: string) => void;
}

const LayersPanel: React.FC<LayersPanelProps> = ({ layers, activeLayerId, onSelectLayer, onAddLayer, onDeleteLayer, onToggleVisibility }) => {
  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300">Layers</h3>
        <IconButton label="Add Layer" onClick={onAddLayer}><AddIcon /></IconButton>
      </div>
      <ul className="space-y-1 bg-gray-100 dark:bg-gray-700 rounded-md p-1 max-h-48 overflow-y-auto">
        {layers.slice().reverse().map(layer => (
          <li
            key={layer.id}
            onClick={() => onSelectLayer(layer.id)}
            className={`flex items-center justify-between p-2 rounded-md cursor-pointer transition-colors ${
              layer.id === activeLayerId
                ? 'bg-blue-200 dark:bg-blue-800'
                : 'hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            <span className="truncate mr-2">{layer.name}</span>
            <div className="flex items-center space-x-1 flex-shrink-0">
                <button 
                  onClick={(e) => { e.stopPropagation(); onToggleVisibility(layer.id); }}
                  className="p-1 rounded hover:bg-gray-300 dark:hover:bg-gray-500 text-gray-600 dark:text-gray-300"
                  title={layer.visible ? "Hide Layer" : "Show Layer"}
                >
                    {layer.visible ? <EyeOpenIcon /> : <EyeClosedIcon />}
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); onDeleteLayer(layer.id); }}
                  className={`p-1 rounded text-gray-600 dark:text-gray-300 ${layers.length <= 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-red-200 dark:hover:bg-red-800'}`}
                  disabled={layers.length <= 1}
                  title="Delete Layer"
                >
                    <TrashIcon />
                </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default LayersPanel;
