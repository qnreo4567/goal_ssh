import React from 'react';
import type { CanvasPreset } from '../types';

interface CanvasPresetCardProps {
  preset: CanvasPreset;
  isSelected: boolean;
  onSelect: (preset: CanvasPreset) => void;
}

const CanvasPresetCard: React.FC<CanvasPresetCardProps> = ({ preset, isSelected, onSelect }) => {
  const getDimensionString = () => {
    if (preset.unit === 'px') {
        return `${preset.width} × ${preset.height}px`;
    }
    return `${preset.physicalWidth} × ${preset.physicalHeight}${preset.unit}`;
  }

  return (
    <button
      onClick={() => onSelect(preset)}
      className={`p-4 rounded-xl text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-gray-800
        ${isSelected
          ? 'bg-blue-100 dark:bg-blue-900/50 border-2 border-blue-500 shadow-lg'
          : 'bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent hover:bg-gray-200 dark:hover:bg-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
        }`
      }
    >
      <p className="font-bold text-gray-800 dark:text-gray-200">{preset.name}</p>
      <p className="text-sm text-gray-500 dark:text-gray-400">
        {preset.colorSpace}, {getDimensionString()}
      </p>
    </button>
  );
};

export default CanvasPresetCard;
