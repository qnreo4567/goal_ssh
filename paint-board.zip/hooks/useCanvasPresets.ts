import { useCallback } from 'react';
import useLocalStorage from './useLocalStorage';
import type { CanvasPreset, CanvasOptions, Unit } from '../types';

const DPI = 96;
const mmToIn = 0.0393701;

const convertToPx = (value: number, unit: Unit): number => {
  if (unit === 'mm') {
    return Math.round(value * mmToIn * DPI);
  }
  if (unit === 'in') {
    return Math.round(value * DPI);
  }
  return value; // px
};

// New function to generate a preset that fits the current screen
const getFitToScreenPreset = (): CanvasPreset => {
  // Use a smaller padding for smaller screens (tablets/mobile)
  const padding = window.innerWidth < 768 ? 40 : 160;
  // Calculate the available space for the canvas, considering the padding
  const availableWidth = window.innerWidth - padding;
  const availableHeight = window.innerHeight - padding;
  
  return {
    name: 'Fit to Screen',
    physicalWidth: availableWidth,
    physicalHeight: availableHeight,
    unit: 'px',
    colorSpace: 'sRGB',
    width: availableWidth,
    height: availableHeight,
  };
};


const defaultPresets: CanvasPreset[] = [
  // Prepend the dynamic "Fit to Screen" preset to make it the default
  getFitToScreenPreset(),
  { name: 'Screen Size', physicalWidth: 2388, physicalHeight: 1668, unit: 'px', colorSpace: 'P3', width: 2388, height: 1668 },
  { name: 'Square', physicalWidth: 2048, physicalHeight: 2048, unit: 'px', colorSpace: 'sRGB', width: 2048, height: 2048 },
  { name: '4K', physicalWidth: 4096, physicalHeight: 1714, unit: 'px', colorSpace: 'sRGB', width: 4096, height: 1714 },
  { name: 'A4', physicalWidth: 210, physicalHeight: 297, unit: 'mm', colorSpace: 'sRGB', width: convertToPx(210, 'mm'), height: convertToPx(297, 'mm') },
  { name: '4x6 Photo', physicalWidth: 6, physicalHeight: 4, unit: 'in', colorSpace: 'sRGB', width: convertToPx(6, 'in'), height: convertToPx(4, 'in') },
  { name: 'Paper', physicalWidth: 11, physicalHeight: 8.5, unit: 'in', colorSpace: 'sRGB', width: convertToPx(11, 'in'), height: convertToPx(8.5, 'in') },
  { name: 'Comic', physicalWidth: 6, physicalHeight: 9, unit: 'in', colorSpace: 'CMYK', width: convertToPx(6, 'in'), height: convertToPx(9, 'in') },
  { name: 'Webtoon', physicalWidth: 3444, physicalHeight: 1945, unit: 'px', colorSpace: 'P3', width: 3444, height: 1945 },
];


export const useCanvasPresets = () => {
  const [recentPresets, setRecentPresets] = useLocalStorage<CanvasPreset[]>('recentCanvasPresets', []);

  const addRecentPreset = useCallback((options: Omit<CanvasPreset, 'name'>) => {
    const newPreset: CanvasPreset = {
      ...options,
      name: 'Custom',
    };
    
    setRecentPresets(prev => {
      // Avoid duplicates
      const exists = prev.some(p => p.width === newPreset.width && p.height === newPreset.height);
      if (exists) return prev;
      
      const updated = [newPreset, ...prev];
      return updated.slice(0, 5); // Keep only the 5 most recent
    });
  }, [setRecentPresets]);

  return { defaultPresets, recentPresets, addRecentPreset };
};