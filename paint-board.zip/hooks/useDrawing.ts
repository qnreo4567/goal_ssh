import { useRef, useEffect, useState, useCallback } from 'react';
import type { Point, Tool, PanOffset } from '../types';

interface UseDrawingProps {
  width: number;
  height: number;
  color: string;
  brushSize: number;
  opacity: number;
  flow: number;
  jitter: number;
  tool: Tool;
  isBaseLayer: boolean;
  isPanActive: boolean;
  initialImageData?: string;
  zoom: number;
  pan: PanOffset;
}

const hexToRgba = (hex: string, alpha: number): string => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

const useDrawing = (props: UseDrawingProps) => {
  const { width, height, color, brushSize, opacity, flow, jitter, tool, isBaseLayer, isPanActive, initialImageData, zoom, pan } = props;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawing = useRef(false);
  const lastPoint = useRef<Point | null>(null);

  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  const getCanvasContext = useCallback(() => {
    const canvas = canvasRef.current;
    return canvas ? canvas.getContext('2d') : null;
  }, []);
  
  const saveToHistory = useCallback(() => {
    const context = getCanvasContext();
    if (!context || !canvasRef.current) return;

    // FIX: Add a guard to prevent errors when the canvas has zero dimensions.
    // This can occur during re-renders or initialization, and calling getImageData
    // with a zero width or height throws a RangeError.
    if (width === 0 || height === 0) {
      return;
    }
    
    const imageData = context.getImageData(0, 0, width, height);
    
    setHistory(prevHistory => {
        const newHistory = prevHistory.slice(0, historyIndex + 1);
        newHistory.push(imageData);
        return newHistory;
    });
    setHistoryIndex(prevIndex => prevIndex + 1);
  }, [getCanvasContext, historyIndex, width, height]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = getCanvasContext();
    if (!canvas || !context) return;
    
    let isInitialized = false;

    const initializeCanvas = () => {
        if (isInitialized) return;

        if (initialImageData) {
            const image = new Image();
            image.onload = () => {
                context.clearRect(0, 0, width, height);
                context.drawImage(image, 0, 0, width, height);
                saveToHistory();
                isInitialized = true;
            };
            image.src = initialImageData;
        } else {
             if (isBaseLayer) {
                context.fillStyle = '#FFFFFF';
                context.fillRect(0, 0, width, height);
            } else {
                context.clearRect(0, 0, width, height);
            }
            saveToHistory();
            isInitialized = true;
        }
    }
    
    initializeCanvas();

  }, [getCanvasContext, saveToHistory, isBaseLayer, initialImageData, width, height]);
  
  const getCoordinates = (event: MouseEvent | TouchEvent): Point | null => {
    if (!canvasRef.current) return null;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    let clientX, clientY;
    if (event instanceof MouseEvent) {
        clientX = event.clientX;
        clientY = event.clientY;
    } else if (event.touches && event.touches.length > 0) {
        clientX = event.touches[0].clientX;
        clientY = event.touches[0].clientY;
    } else {
        return null;
    }
    
    const x = (clientX - rect.left - pan.x) / zoom;
    const y = (clientY - rect.top - pan.y) / zoom;
    return { x, y };
  };

  const drawLine = useCallback((start: Point, end: Point) => {
    const context = getCanvasContext();
    if (!context) return;
    
    const dist = Math.sqrt(Math.pow(end.x - start.x, 2) + Math.pow(end.y - start.y, 2));
    const angle = Math.atan2(end.y - start.y, end.x - start.x);

    for (let i = 0; i < dist; i += 1) {
        const x = start.x + Math.cos(angle) * i;
        const y = start.y + Math.sin(angle) * i;
        
        const jitterX = (Math.random() - 0.5) * jitter;
        const jitterY = (Math.random() - 0.5) * jitter;

        context.beginPath();
        context.arc(x + jitterX, y + jitterY, brushSize / 2, 0, Math.PI * 2, true);
        context.closePath();
        context.fill();
    }
  }, [getCanvasContext, brushSize, jitter]);

  const startDrawing = useCallback((event: MouseEvent | TouchEvent) => {
    if (isPanActive) return;
    event.preventDefault();
    const point = getCoordinates(event);
    if (!point) return;
    
    isDrawing.current = true;
    lastPoint.current = point;

    const context = getCanvasContext();
    if (!context) return;
    
    const strokeAlpha = opacity * flow;
    
    if (tool === 'eraser') {
      context.globalCompositeOperation = 'destination-out';
      context.fillStyle = `rgba(0,0,0,${strokeAlpha})`;
      if(isBaseLayer){
        context.globalCompositeOperation = 'source-over';
        context.fillStyle = hexToRgba('#FFFFFF', strokeAlpha);
      }
    } else {
      context.globalCompositeOperation = 'source-over';
      context.fillStyle = hexToRgba(color, strokeAlpha);
    }
  }, [brushSize, color, tool, getCanvasContext, isBaseLayer, opacity, flow, isPanActive, zoom, pan]);

  const draw = useCallback((event: MouseEvent | TouchEvent) => {
    if (!isDrawing.current || isPanActive) return;
    event.preventDefault();
    const currentPoint = getCoordinates(event);
    if (!currentPoint || !lastPoint.current) return;
    
    drawLine(lastPoint.current, currentPoint);
    lastPoint.current = currentPoint;
  }, [drawLine, isPanActive, zoom, pan]);

  const stopDrawing = useCallback(() => {
    if (!isDrawing.current) return;
    isDrawing.current = false;
    lastPoint.current = null;
    saveToHistory();
  }, [saveToHistory]);
  
  const clearCanvas = useCallback(() => {
    const context = getCanvasContext();
    if (!context) return;

    // FIX: Add a guard against zero-sized canvases.
    if (width === 0 || height === 0) {
      return;
    }
    
    if (isBaseLayer) {
      context.globalCompositeOperation = 'source-over';
      context.fillStyle = '#FFFFFF';
      context.fillRect(0, 0, width, height);
    } else {
      context.clearRect(0, 0, width, height);
    }
    saveToHistory();
  }, [getCanvasContext, saveToHistory, isBaseLayer, width, height]);

  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      const context = getCanvasContext();
      if (context) context.putImageData(history[newIndex], 0, 0);
    }
  }, [history, historyIndex, getCanvasContext]);

  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      const context = getCanvasContext();
      if (context) context.putImageData(history[newIndex], 0, 0);
    }
  }, [history, historyIndex, getCanvasContext]);

  const getImageData = useCallback(() => canvasRef.current?.toDataURL() ?? '', []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleStart = (e: MouseEvent | TouchEvent) => startDrawing(e);
    const handleMove = (e: MouseEvent | TouchEvent) => draw(e);
    const handleEnd = () => stopDrawing();

    canvas.addEventListener('mousedown', handleStart);
    canvas.addEventListener('mousemove', handleMove);
    canvas.addEventListener('mouseup', handleEnd);
    canvas.addEventListener('mouseleave', handleEnd);
    
    canvas.addEventListener('touchstart', handleStart, { passive: false });
    canvas.addEventListener('touchmove', handleMove, { passive: false });
    canvas.addEventListener('touchend', handleEnd);
    
    return () => {
      canvas.removeEventListener('mousedown', handleStart);
      canvas.removeEventListener('mousemove', handleMove);
      canvas.removeEventListener('mouseup', handleEnd);
      canvas.removeEventListener('mouseleave', handleEnd);

      canvas.removeEventListener('touchstart', handleStart);
      canvas.removeEventListener('touchmove', handleMove);
      canvas.removeEventListener('touchend', handleEnd);
    };
  }, [startDrawing, draw, stopDrawing]);

  return { canvasRef, clearCanvas, undo, redo, getImageData };
};

export default useDrawing;