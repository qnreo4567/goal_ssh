// FIX: Import React to provide the 'React' namespace for types like React.RefObject.
import React, { useState, useRef, useCallback, useEffect } from 'react';

interface Position {
  x: number;
  y: number;
}

export const useDraggable = (
  dragRef: React.RefObject<HTMLElement>,
  containerRef: React.RefObject<HTMLElement>
) => {
  const [position, setPosition] = useState<Position>({ x: 16, y: 16 }); // Initial position
  const isDragging = useRef(false);
  const offset = useRef<Position>({ x: 0, y: 0 });

  const reposition = useCallback(() => {
    const dragElement = dragRef.current;
    const containerElement = containerRef.current;
    if (!dragElement || !containerElement) return;

    const containerRect = containerElement.getBoundingClientRect();
    const dragRect = dragElement.getBoundingClientRect();
    
    setPosition(prevPos => {
      let newX = prevPos.x;
      let newY = prevPos.y;
      if (newX + dragRect.width > containerRect.width) newX = containerRect.width - dragRect.width;
      if (newY + dragRect.height > containerRect.height) newY = containerRect.height - dragRect.height;
      if (newX < 0) newX = 0;
      if (newY < 0) newY = 0;
      return { x: newX, y: newY };
    })
  }, [dragRef, containerRef]);

  const onPointerMove = useCallback((e: PointerEvent) => {
    if (!isDragging.current || !dragRef.current || !containerRef.current) return;
    
    e.preventDefault();

    const containerRect = containerRef.current.getBoundingClientRect();
    const dragRect = dragRef.current.getBoundingClientRect();
    
    let newX = e.clientX - offset.current.x - containerRect.left;
    let newY = e.clientY - offset.current.y - containerRect.top;

    // Boundary checks
    if (newX < 0) newX = 0;
    if (newY < 0) newY = 0;
    if (newX + dragRect.width > containerRect.width) newX = containerRect.width - dragRect.width;
    if (newY + dragRect.height > containerRect.height) newY = containerRect.height - dragRect.height;
    
    setPosition({ x: newX, y: newY });
  }, [dragRef, containerRef]);

  const onPointerUp = useCallback(() => {
    isDragging.current = false;
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
  }, [onPointerMove]);
  
  const onPointerDown = useCallback((e: PointerEvent | React.PointerEvent) => {
    const dragElement = dragRef.current;
    if (!dragElement || !(e.target as HTMLElement).closest('.cursor-grab')) return;

    e.preventDefault();
    
    isDragging.current = true;
    const rect = dragElement.getBoundingClientRect();
    offset.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };

    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
  }, [dragRef, onPointerMove, onPointerUp]);


  useEffect(() => {
    window.addEventListener('resize', reposition);
    // Use a timeout to ensure the initial layout is stable
    const timeoutId = setTimeout(reposition, 100);

    return () => {
        window.removeEventListener('resize', reposition);
        clearTimeout(timeoutId);
    }
  }, [reposition]);

  return {
    position,
    onPointerDown,
    reposition,
  };
};
