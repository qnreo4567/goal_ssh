import React, { useState, useRef, useCallback, useEffect } from 'react';
import Toolbar from './components/Toolbar';
import Canvas from './components/Canvas';
import NewCanvasModal from './components/NewCanvasModal'; 
import type { CanvasActions, Layer, CanvasOptions, Tool, ProjectFile, PanOffset } from './types';

// Simple UUID v4 generator
const uuidv4 = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

const App: React.FC = () => {
  // Tool State
  const [color, setColor] = useState<string>('#000000');
  const [brushSize, setBrushSize] = useState<number>(5);
  const [opacity, setOpacity] = useState<number>(1);
  const [flow, setFlow] = useState<number>(1);
  const [jitter, setJitter] = useState<number>(0);
  const [tool, setTool] = useState<Tool>('pen');

  // Canvas and Layer State
  const [canvasOptions, setCanvasOptions] = useState<CanvasOptions>({ width: 1024, height: 768 });
  const [isNewCanvasModalOpen, setIsNewCanvasModalOpen] = useState(true);
  const [initialLayerId, setInitialLayerId] = useState(() => uuidv4());
  const [layers, setLayers] = useState<Layer[]>([
    { id: initialLayerId, name: 'Layer 1', visible: true },
  ]);
  const [activeLayerId, setActiveLayerId] = useState<string>(initialLayerId);
  const [initialLayerData, setInitialLayerData] = useState<Record<string, string> | null>(null);

  // View State
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState<PanOffset>({ x: 0, y: 0 });
  const [isPanMode, setIsPanMode] = useState(false); // For spacebar panning

  const layerActionsRef = useRef<Map<string, CanvasActions>>(new Map());
  const mainContainerRef = useRef<HTMLDivElement>(null);

  const handleCreateCanvas = useCallback((options: CanvasOptions) => {
    setCanvasOptions(options);
    
    // Reset state completely
    const newInitialLayerId = uuidv4();
    setInitialLayerId(newInitialLayerId);
    const newLayers = [{ id: newInitialLayerId, name: 'Layer 1', visible: true }];
    setLayers(newLayers);
    setActiveLayerId(newInitialLayerId);
    layerActionsRef.current.clear();
    setInitialLayerData(null); // Clear any loaded data
    setZoom(1);
    setPan({x: 0, y: 0});
    
    setIsNewCanvasModalOpen(false);
  }, []);
  
  const handleSaveProject = useCallback(() => {
    const layerData: Record<string, string> = {};
    for(const layer of layers) {
        const actions = layerActionsRef.current.get(layer.id);
        if (actions) {
            layerData[layer.id] = actions.getImageData();
        }
    }

    const projectFile: ProjectFile = {
        canvasOptions,
        layers,
        layerData,
        toolSettings: { tool, color, brushSize, opacity, flow, jitter },
        viewTransform: { zoom, pan },
        activeLayerId,
        initialLayerId
    };

    const blob = new Blob([JSON.stringify(projectFile, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'my-project.gemini-paint';
    a.click();
    URL.revokeObjectURL(url);

  }, [layers, canvasOptions, tool, color, brushSize, opacity, flow, jitter, zoom, pan, activeLayerId, initialLayerId]);

  const handleLoadProject = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const result = e.target?.result;
            if (typeof result !== 'string') throw new Error("File is not valid text");
            
            const data = JSON.parse(result) as ProjectFile;

            // Restore all state from the file
            setCanvasOptions(data.canvasOptions);
            setLayers(data.layers);
            setTool(data.toolSettings.tool);
            setColor(data.toolSettings.color);
            setBrushSize(data.toolSettings.brushSize);
            setOpacity(data.toolSettings.opacity);
            setFlow(data.toolSettings.flow);
            setJitter(data.toolSettings.jitter);
            setZoom(data.viewTransform.zoom);
            setPan(data.viewTransform.pan);
            setActiveLayerId(data.activeLayerId);
            setInitialLayerId(data.initialLayerId);
            setInitialLayerData(data.layerData); // Set initial data for canvases
            
            setIsNewCanvasModalOpen(false); // Close modal if open

        } catch (error) {
            console.error("Failed to load project file:", error);
            alert("Error: Could not load the project file. It may be invalid or corrupted.");
        }
    };
    reader.readAsText(file);
  }, []);

  // Effect for spacebar pan mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !e.repeat) {
        setIsPanMode(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        setIsPanMode(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const registerActions = useCallback((layerId: string, actions: CanvasActions) => {
    layerActionsRef.current.set(layerId, actions);
  }, []);

  useEffect(() => {
    const layerIds = new Set(layers.map(l => l.id));
    for (const id of layerActionsRef.current.keys()) {
      if (!layerIds.has(id)) {
        layerActionsRef.current.delete(id);
      }
    }
  }, [layers]);

  const handleClear = useCallback(() => layerActionsRef.current.get(activeLayerId)?.clear(), [activeLayerId]);
  const handleUndo = useCallback(() => layerActionsRef.current.get(activeLayerId)?.undo(), [activeLayerId]);
  const handleRedo = useCallback(() => layerActionsRef.current.get(activeLayerId)?.redo(), [activeLayerId]);

  const handleAddLayer = useCallback(() => {
    const newLayer: Layer = { id: uuidv4(), name: `Layer ${layers.length + 1}`, visible: true };
    setLayers(prev => [...prev, newLayer]);
    setActiveLayerId(newLayer.id);
  }, [layers.length]);

  const handleDeleteLayer = useCallback((id: string) => {
    if (layers.length <= 1) return;
    const remainingLayers = layers.filter(l => l.id !== id);
    setLayers(remainingLayers);
    if (activeLayerId === id) {
      const deletedIndex = layers.findIndex(l => l.id === id);
      const newActiveIndex = Math.max(0, deletedIndex - 1);
      setActiveLayerId(remainingLayers[newActiveIndex]?.id || remainingLayers[0]?.id);
    }
  }, [layers, activeLayerId]);

  const handleSelectLayer = useCallback((id: string) => setActiveLayerId(id), []);
  const handleToggleVisibility = useCallback((id: string) => {
    setLayers(prev => prev.map(l => l.id === id ? { ...l, visible: !l.visible } : l));
  }, []);

  return (
    <div className="flex flex-col h-screen font-sans text-gray-800 dark:text-gray-200 antialiased overflow-hidden">
      <div ref={mainContainerRef} className="flex-1 relative overflow-hidden bg-gray-200 dark:bg-gray-700">
        <main className="w-full h-full flex items-center justify-center p-2 md:p-4">
          <Canvas
            key={initialLayerId}
            options={canvasOptions}
            color={color}
            brushSize={brushSize}
            opacity={opacity}
            flow={flow}
            jitter={jitter}
            tool={tool}
            layers={layers}
            activeLayerId={activeLayerId}
            initialLayerId={initialLayerId}
            registerActions={registerActions}
            initialLayerData={initialLayerData}
            zoom={zoom}
            setZoom={setZoom}
            pan={pan}
            setPan={setPan}
            isPanActive={isPanMode || tool === 'pan'}
          />
        </main>
        
        <Toolbar
          containerRef={mainContainerRef}
          color={color}
          setColor={setColor}
          brushSize={brushSize}
          setBrushSize={setBrushSize}
          opacity={opacity}
          setOpacity={setOpacity}
          flow={flow}
          setFlow={setFlow}
          jitter={jitter}
          setJitter={setJitter}
          tool={tool}
          setTool={setTool}
          onClear={handleClear}
          onUndo={handleUndo}
          onRedo={handleRedo}
          layers={layers}
          activeLayerId={activeLayerId}
          onAddLayer={handleAddLayer}
          onDeleteLayer={handleDeleteLayer}
          onSelectLayer={handleSelectLayer}
          onToggleVisibility={handleToggleVisibility}
          onNewCanvasClick={() => setIsNewCanvasModalOpen(true)}
          onSaveProject={handleSaveProject}
          onLoadProject={handleLoadProject}
        />
      </div>

      <NewCanvasModal
        isOpen={isNewCanvasModalOpen}
        onClose={() => setIsNewCanvasModalOpen(false)}
        onCreateCanvas={handleCreateCanvas}
      />
    </div>
  );
};

export default App;
